#include "system_task_handle.h"
#include "Robot_Arm.h"
#include "Arduino.h"
#include <string.h>

void pump_at32_feedback(void);
bool sync_arm_feedback(uint32_t timeout_ms);

namespace {

CommProtocol_t at32_protocol;

uint32_t last_oled_refresh_ms = 0;
uint32_t last_bat_refresh_ms = 0;
uint32_t last_status_sync_ms = 0;
uint32_t button_enable_ms = 0;
uint32_t last_servo_feedback_ms = 0;

int16_t last_servo_positions[6] = {2048, 2048, 2048, 2048, 2048, 2048};

uint8_t current_speed_index = 0;
bool path_toggle = false;

constexpr uint32_t OLED_REFRESH_INTERVAL_MS = 80;
constexpr uint32_t BAT_REFRESH_INTERVAL_MS = 200;
constexpr uint32_t STATUS_SYNC_INTERVAL_MS = 500;
constexpr uint32_t BUTTON_STARTUP_GUARD_MS = 1500;

struct PoseTarget {
    float x;
    float y;
    float z;
    float pitch;
    float roll;
    float claw;
};

struct SpeedPlan {
    const char* name;
    uint8_t move_acc;
    uint16_t duration_ms;
};

const PoseTarget kHomePose = {200.0f, 0.0f, 200.0f, 0.0f, 0.0f, 0.0f};
const PoseTarget kLeftPose = {210.0f, 90.0f, 170.0f, -8.0f, 0.0f, 10.0f};
const PoseTarget kRightPose = {210.0f, -90.0f, 170.0f, -8.0f, 0.0f, 10.0f};
const PoseTarget kApproachPose = {190.0f, 0.0f, 240.0f, 8.0f, 0.0f, 0.0f};
const PoseTarget kSettlePose = {210.0f, -45.0f, 185.0f, -5.0f, 0.0f, 8.0f};

const SpeedPlan kSpeedPlans[] = {
    {"gentle", 10, 2800},
    {"balanced", 35, 1600},
    {"aggressive", 75, 850},
};

// Move to one target with acceleration and duration plan(按加速度和时间规划运动到目标位姿)
void move_with_plan(const PoseTarget& pose, const SpeedPlan& plan)
{
    arm.set_torque(true);
    arm.set_move_acc(plan.move_acc);
    Serial.printf(
        "[Speed] plan=%s acc=%u duration=%u -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
        plan.name,
        plan.move_acc,
        plan.duration_ms,
        pose.x,
        pose.y,
        pose.z,
        pose.pitch,
        pose.roll,
        pose.claw
    );
    arm.move(pose.x, pose.y, pose.z, pose.pitch, pose.roll, pose.claw, plan.duration_ms);
    arm.board.buzzer.set(80, 50, 1, 2000);
}

// Run a multi-stage speed planning demo with different acceleration profiles(运行包含不同加速度曲线的多阶段速度规划演示)
void run_staged_speed_demo()
{
    const SpeedPlan stage_depart = {"depart", 8, 2200};
    const SpeedPlan stage_cruise = {"cruise", 70, 950};
    const SpeedPlan stage_settle = {"settle", 18, 1700};

    arm.set_torque(true);
    Serial.println("[Speed] staged demo start");

    Serial.printf(
        "[Speed] stage 1(depart) acc=%u duration=%u -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
        stage_depart.move_acc,
        stage_depart.duration_ms,
        kApproachPose.x,
        kApproachPose.y,
        kApproachPose.z,
        kApproachPose.pitch,
        kApproachPose.roll,
        kApproachPose.claw
    );
    arm.set_move_acc(stage_depart.move_acc);
    arm.move(
        kApproachPose.x,
        kApproachPose.y,
        kApproachPose.z,
        kApproachPose.pitch,
        kApproachPose.roll,
        kApproachPose.claw,
        stage_depart.duration_ms
    );
    delay(stage_depart.duration_ms + 120);

    Serial.printf(
        "[Speed] stage 2(cruise) acc=%u duration=%u -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
        stage_cruise.move_acc,
        stage_cruise.duration_ms,
        kRightPose.x,
        kRightPose.y,
        kRightPose.z,
        kRightPose.pitch,
        kRightPose.roll,
        kRightPose.claw
    );
    arm.set_move_acc(stage_cruise.move_acc);
    arm.move(
        kRightPose.x,
        kRightPose.y,
        kRightPose.z,
        kRightPose.pitch,
        kRightPose.roll,
        kRightPose.claw,
        stage_cruise.duration_ms
    );
    delay(stage_cruise.duration_ms + 120);

    Serial.printf(
        "[Speed] stage 3(settle) acc=%u duration=%u -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
        stage_settle.move_acc,
        stage_settle.duration_ms,
        kSettlePose.x,
        kSettlePose.y,
        kSettlePose.z,
        kSettlePose.pitch,
        kSettlePose.roll,
        kSettlePose.claw
    );
    arm.set_move_acc(stage_settle.move_acc);
    arm.move(
        kSettlePose.x,
        kSettlePose.y,
        kSettlePose.z,
        kSettlePose.pitch,
        kSettlePose.roll,
        kSettlePose.claw,
        stage_settle.duration_ms
    );
    delay(stage_settle.duration_ms + 120);

    Serial.printf(
        "[Speed] stage 4(home) acc=%u duration=%u -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
        stage_settle.move_acc,
        stage_settle.duration_ms,
        kHomePose.x,
        kHomePose.y,
        kHomePose.z,
        kHomePose.pitch,
        kHomePose.roll,
        kHomePose.claw
    );
    arm.set_move_acc(stage_settle.move_acc);
    arm.move(
        kHomePose.x,
        kHomePose.y,
        kHomePose.z,
        kHomePose.pitch,
        kHomePose.roll,
        kHomePose.claw,
        stage_settle.duration_ms
    );
    arm.board.buzzer.set(60, 60, 2, 2200);
}

// Decode tcp pose fields from one AT32 packet(从一帧AT32数据中解析末端位姿字段)
void parse_pose_from_packet(PacketTypeDef* rx_packet, ArmPose_t& pose)
{
    if (rx_packet->elements.length < 14) {
        return;
    }

    int16_t raw_x = (int16_t)((rx_packet->elements.args[1] << 8) | rx_packet->elements.args[0]);
    int16_t raw_y = (int16_t)((rx_packet->elements.args[3] << 8) | rx_packet->elements.args[2]);
    int16_t raw_z = (int16_t)((rx_packet->elements.args[5] << 8) | rx_packet->elements.args[4]);
    int16_t raw_pitch = (int16_t)((rx_packet->elements.args[7] << 8) | rx_packet->elements.args[6]);
    int16_t raw_roll = (int16_t)((rx_packet->elements.args[9] << 8) | rx_packet->elements.args[8]);
    int16_t raw_claw = (int16_t)((rx_packet->elements.args[11] << 8) | rx_packet->elements.args[10]);

    pose.x = (float)raw_x;
    pose.y = (float)raw_y;
    pose.z = (float)raw_z;
    pose.pitch = (float)raw_pitch / 10.0f;
    pose.roll = (float)raw_roll;
    pose.claw = (float)raw_claw;
}

// Cache latest pose and servo feedback locally(在本地缓存最新位姿和舵机反馈)
void update_pose_from_packet(PacketTypeDef* rx_packet)
{
    parse_pose_from_packet(rx_packet, arm.current_pose);

    if (rx_packet->elements.cmd == CMD_GET_CUR_COORDS && rx_packet->elements.length >= 26) {
        for (int i = 0; i < 6; ++i) {
            int idx = 12 + i * 2;
            last_servo_positions[i] = (int16_t)((rx_packet->elements.args[idx + 1] << 8) | rx_packet->elements.args[idx]);
        }
        last_servo_feedback_ms = millis();
    }
}

} // namespace

// Handle parsed packets returned from AT32(处理AT32返回并已解析完成的数据包)
void at32_packet_callback(PacketTypeDef* rx_packet)
{
    if (rx_packet->elements.id != 0x5A) {
        return;
    }

    if (rx_packet->elements.cmd == CMD_GET_CUR_COORDS) {
        update_pose_from_packet(rx_packet);
    }
}

// Feed uart bytes into the AT32 protocol parser(把串口字节送入AT32协议解析器)
void pump_at32_feedback(void)
{
    while (servo.uart->available()) {
        uint8_t c = servo.uart->read();
        at32_protocol.parsing(&c, 1);
    }
}

// Wait until one fresh status frame is received(等待收到一帧新的状态反馈)
bool sync_arm_feedback(uint32_t timeout_ms)
{
    arm.update_status();
    uint32_t start = millis();
    uint32_t prev_feedback_ms = last_servo_feedback_ms;

    while (millis() - start < timeout_ms) {
        pump_at32_feedback();
        if (last_servo_feedback_ms != 0 && last_servo_feedback_ms != prev_feedback_ms) {
            return true;
        }
        delay(2);
    }

    return last_servo_feedback_ms != 0;
}

// Export latest cached servo positions for board helpers(给板级辅助逻辑导出最新舵机位置)
bool get_last_servo_positions(int16_t out_pos[6])
{
    if (last_servo_feedback_ms == 0) {
        return false;
    }

    memcpy(out_pos, last_servo_positions, sizeof(last_servo_positions));
    return true;
}

// Run one-time startup initialization only once(仅执行一次的启动初始化)
void register_system_task(esp_event_loop_handle_t *event_loop)
{
    (void)event_loop;

    setCpuFrequencyMhz(240);
    Serial.begin(115200);

    servo.begin(Serial1, 1000000, 16, 17);
    arm.begin();

    at32_protocol.begin();
    at32_protocol.register_success_callback(at32_packet_callback);

    sync_arm_feedback(300);
    arm.board.button.update();
    arm.board.button.is_clicked(0);
    arm.board.button.is_clicked(1);
    button_enable_ms = millis() + BUTTON_STARTUP_GUARD_MS;

    Serial.println("[Demo] initialization finished");
    Serial.println("[Demo] press BOOT for single-stage speed plan(acc + time)");
    Serial.println("[Demo] press USER for multi-stage speed planning demo");
}

// Keep the speed planning demo alive in the main loop(在主循环中维持速度规划演示运行)
void system_loop_handler(void)
{
    // Continuously receive feedback from AT32(持续接收AT32反馈)
    pump_at32_feedback();
    arm.board.button.update();
    arm.board.buzzer.update();

    uint32_t now = millis();

    if (now - last_bat_refresh_ms >= BAT_REFRESH_INTERVAL_MS) {
        last_bat_refresh_ms = now;
        arm.board.bat.update();
    }

    if (now - last_status_sync_ms >= STATUS_SYNC_INTERVAL_MS) {
        last_status_sync_ms = now;
        arm.update_status();
    }

    if (now - last_oled_refresh_ms >= OLED_REFRESH_INTERVAL_MS) {
        last_oled_refresh_ms = now;
        arm.board.oled.show_status(
            arm.current_pose.x,
            arm.current_pose.y,
            arm.current_pose.z,
            arm.current_pose.pitch,
            arm.current_pose.roll,
            arm.current_pose.claw
        );
    }

    // BOOT button triggers one target with different acceleration and time plans(BOOT按键触发同一类目标的不同加速度和时间规划)
    if (now >= button_enable_ms && arm.board.button.is_clicked(0)) {
        const PoseTarget& target = path_toggle ? kLeftPose : kRightPose;
        const SpeedPlan& plan = kSpeedPlans[current_speed_index];
        move_with_plan(target, plan);

        current_speed_index = (current_speed_index + 1) % (sizeof(kSpeedPlans) / sizeof(kSpeedPlans[0]));
        path_toggle = !path_toggle;
    }

    // USER button triggers a multi-stage speed planning sequence(USER按键触发一段多阶段速度规划序列)
    if (now >= button_enable_ms && arm.board.button.is_clicked(1)) {
        run_staged_speed_demo();
    }
}
