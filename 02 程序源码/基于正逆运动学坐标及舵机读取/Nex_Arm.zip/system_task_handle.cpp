#include "system_task_handle.h"
#include "Robot_Arm.h"
#include "Arduino.h"
#include <string.h>

void pump_at32_feedback(void);
bool sync_arm_feedback(uint32_t timeout_ms);

namespace {

CommProtocol_t at32_protocol;

uint32_t last_oled_refresh_ms = 0;
uint32_t last_bat_refresh_ms = 0;
uint32_t button_enable_ms = 0;
uint32_t last_pose_feedback_ms = 0;
uint32_t last_servo_feedback_ms = 0;

int16_t last_servo_positions[6] = {2048, 2048, 2048, 2048, 2048, 2048};

constexpr uint32_t OLED_REFRESH_INTERVAL_MS = 80;
constexpr uint32_t BAT_REFRESH_INTERVAL_MS = 200;
constexpr uint32_t BUTTON_STARTUP_GUARD_MS = 1500;

struct FkJoints {
    float j1;
    float j2;
    float j3;
    float j4;
    float roll;
    float claw;
};

uint8_t current_fk_index = 0;

FkJoints last_requested_fk = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};

const FkJoints kFkReadTargets[] = {
    {0.0f, 90.0f, -150.0f, 45.0f, 0.0f, 0.0f},
    {10.0f, 90.0f, -150.0f, 14.0f, 0.0f, 10.0f},
    {-10.0f, 90.0f, -150.0f, 12.0f, 8.0f, 0.0f},
};

// Decode tcp pose from one response packet(从一帧响应包中解析末端位姿)
void parse_pose_from_packet(PacketTypeDef* rx_packet, ArmPose_t& pose)
{
    if (rx_packet->elements.length < 14) {
        return;
    }

    int16_t raw_x = (int16_t)((rx_packet->elements.args[1] << 8) | rx_packet->elements.args[0]);
    int16_t raw_y = (int16_t)((rx_packet->elements.args[3] << 8) | rx_packet->elements.args[2]);
    int16_t raw_z = (int16_t)((rx_packet->elements.args[5] << 8) | rx_packet->elements.args[4]);
    int16_t raw_pitch = (int16_t)((rx_packet->elements.args[7] << 8) | rx_packet->elements.args[6]);
    int16_t raw_roll = (int16_t)((rx_packet->elements.args[9] << 8) | rx_packet->elements.args[8]);
    int16_t raw_claw = (int16_t)((rx_packet->elements.args[11] << 8) | rx_packet->elements.args[10]);

    pose.x = (float)raw_x;
    pose.y = (float)raw_y;
    pose.z = (float)raw_z;
    pose.pitch = (float)raw_pitch / 10.0f;
    pose.roll = (float)raw_roll;
    pose.claw = (float)raw_claw;
}

// Decode six servo values from one response packet(从一帧响应包中解析6个舵机值)
bool parse_servo_positions_from_packet(PacketTypeDef* rx_packet, int16_t servo_pos[6])
{
    if (rx_packet->elements.length < 26) {
        return false;
    }

    for (int i = 0; i < 6; ++i) {
        int idx = 12 + i * 2;
        servo_pos[i] = (int16_t)((rx_packet->elements.args[idx + 1] << 8) | rx_packet->elements.args[idx]);
    }
    return true;
}

// Cache the latest realtime feedback locally(在本地缓存最新实时反馈)
void update_cached_feedback(PacketTypeDef* rx_packet)
{
    if (rx_packet->elements.length >= 14) {
        parse_pose_from_packet(rx_packet, arm.current_pose);
        last_pose_feedback_ms = millis();
    }

    if (parse_servo_positions_from_packet(rx_packet, last_servo_positions)) {
        last_servo_feedback_ms = millis();
    }
}

// Print six servo positions in one line(用一行打印6个舵机位置)
void print_servo_positions(const int16_t servo_pos[6])
{
    Serial.printf(
        "servo_pos=(%d, %d, %d, %d, %d, %d)\n",
        servo_pos[0], servo_pos[1], servo_pos[2],
        servo_pos[3], servo_pos[4], servo_pos[5]
    );
}

// Request one inverse kinematics read sample(请求一组逆运动学读取示例)
// Request one forward kinematics read sample(请求一组正运动学读取示例)
// Request the current measured coordinate from AT32.
void request_current_pose_read(void)
{
    uint32_t prev_pose_feedback_ms = last_pose_feedback_ms;
    uint32_t prev_servo_feedback_ms = last_servo_feedback_ms;

    arm.update_status();
    uint32_t start = millis();
    while (millis() - start < 120) {
        pump_at32_feedback();
        if (last_pose_feedback_ms != 0 && last_pose_feedback_ms != prev_pose_feedback_ms) {
            Serial.printf(
                "[CUR] result -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
                arm.current_pose.x,
                arm.current_pose.y,
                arm.current_pose.z,
                arm.current_pose.pitch,
                arm.current_pose.roll,
                arm.current_pose.claw
            );

            if (last_servo_feedback_ms != 0 && last_servo_feedback_ms != prev_servo_feedback_ms) {
                print_servo_positions(last_servo_positions);
            }
            return;
        }
        delay(2);
    }

    Serial.println("[CUR] read timeout");
}

void request_fk_read(uint8_t index)
{
    const FkJoints& joints = kFkReadTargets[index % (sizeof(kFkReadTargets) / sizeof(kFkReadTargets[0]))];
    last_requested_fk = joints;

    Serial.printf(
        "[FK] request joints=(%.1f, %.1f, %.1f, %.1f) roll=%.1f claw=%.1f\n",
        joints.j1, joints.j2, joints.j3, joints.j4, joints.roll, joints.claw
    );

    arm.request_fk_calc(joints.j1, joints.j2, joints.j3, joints.j4, joints.roll, joints.claw);
    arm.board.buzzer.set(60, 60, 1, 2200);
}

} // namespace

// Handle parsed packets returned from AT32(处理来自AT32且已解析完成的数据包)
void at32_packet_callback(PacketTypeDef* rx_packet)
{
    if (rx_packet->elements.id != 0x5A) {
        return;
    }

    if (rx_packet->elements.cmd == CMD_GET_CUR_COORDS) {
        update_cached_feedback(rx_packet);
        return;
    }

    if (rx_packet->elements.cmd == CMD_IKINE_RESULT_GET) {
        // IK read returns tcp pose plus servo targets(逆运动学读取会返回末端位姿和舵机目标值)
        ArmPose_t pose = {};
        int16_t servo_pos[6] = {0};
        parse_pose_from_packet(rx_packet, pose);
        parse_servo_positions_from_packet(rx_packet, servo_pos);
        Serial.printf(
            "[IK] result -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
            pose.x, pose.y, pose.z, pose.pitch, pose.roll, pose.claw
        );
        print_servo_positions(servo_pos);
        return;
    }

    if (rx_packet->elements.cmd == CMD_FKINE_RESULT_GET) {
        // FK read returns tcp pose plus equivalent servo values(正运动学读取会返回末端位姿和对应舵机值)
        ArmPose_t pose = {};
        int16_t servo_pos[6] = {0};
        parse_pose_from_packet(rx_packet, pose);
        parse_servo_positions_from_packet(rx_packet, servo_pos);
        Serial.printf(
            "[FK] result -> x=%.1f y=%.1f z=%.1f pitch=%.1f roll=%.1f claw=%.1f\n",
            pose.x, pose.y, pose.z, pose.pitch, pose.roll, pose.claw
        );
        print_servo_positions(servo_pos);
    }
}

// Feed uart bytes into the AT32 parser(把串口字节送入AT32解析器)
void pump_at32_feedback(void)
{
    while (servo.uart->available()) {
        uint8_t c = servo.uart->read();
        at32_protocol.parsing(&c, 1);
    }
}

// Wait for one fresh feedback frame(等待一帧新的反馈数据)
bool sync_arm_feedback(uint32_t timeout_ms)
{
    arm.update_status();
    uint32_t start = millis();
    uint32_t prev_feedback_ms = last_servo_feedback_ms;

    while (millis() - start < timeout_ms) {
        pump_at32_feedback();
        if (last_servo_feedback_ms != 0 && last_servo_feedback_ms != prev_feedback_ms) {
            return true;
        }
        delay(2);
    }

    return last_servo_feedback_ms != 0;
}

// Export cached servo positions for helper code(给辅助逻辑导出缓存的舵机位置)
bool get_last_servo_positions(int16_t out_pos[6])
{
    if (last_servo_feedback_ms == 0) {
        return false;
    }

    memcpy(out_pos, last_servo_positions, sizeof(last_servo_positions));
    return true;
}

// Run one-time startup initialization(执行一次性的启动初始化)
void register_system_task(esp_event_loop_handle_t *event_loop)
{
    (void)event_loop;

    setCpuFrequencyMhz(240);
    Serial.begin(115200);

    servo.begin(Serial1, 1000000, 16, 17);
    arm.begin();

    at32_protocol.begin();
    at32_protocol.register_success_callback(at32_packet_callback);

    sync_arm_feedback(300);
    current_fk_index = 0;
    arm.board.button.update();
    arm.board.button.is_clicked(0);
    arm.board.button.is_clicked(1);
    button_enable_ms = millis() + BUTTON_STARTUP_GUARD_MS;

    Serial.println("[Demo] initialization finished");
    Serial.println("[Demo] press BOOT for current coordinate read");
    Serial.println("[Demo] press USER for forward kinematics read");
}

// Run the main read demo loop(运行主读取演示循环)
void system_loop_handler(void)
{
    // Continuously receive feedback from AT32(持续接收AT32反馈)
    pump_at32_feedback();
    arm.board.button.update();
    arm.board.buzzer.update();

    uint32_t now = millis();

    if (now - last_bat_refresh_ms >= BAT_REFRESH_INTERVAL_MS) {
        last_bat_refresh_ms = now;
        arm.board.bat.update();
    }

    if (now - last_oled_refresh_ms >= OLED_REFRESH_INTERVAL_MS) {
        last_oled_refresh_ms = now;
        arm.board.oled.show_status(
            arm.current_pose.x,
            arm.current_pose.y,
            arm.current_pose.z,
            arm.current_pose.pitch,
            arm.current_pose.roll,
            arm.current_pose.claw
        );
    }

    // BOOT button triggers one IK read request(BOOT按键触发一次逆运动学读取)
    if (now >= button_enable_ms && arm.board.button.is_clicked(0)) {
        request_current_pose_read();
        arm.board.buzzer.set(80, 60, 1, 2000);
    }

    // USER button triggers one FK read request(USER按键触发一次正运动学读取)
    if (now >= button_enable_ms && arm.board.button.is_clicked(1)) {
        request_fk_read(current_fk_index);
        current_fk_index = (current_fk_index + 1) % (sizeof(kFkReadTargets) / sizeof(kFkReadTargets[0]));
    }
}
